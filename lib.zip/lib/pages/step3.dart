import 'package:flutter/material.dart';

class step3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('STEP 3'),
          backgroundColor: Colors.red,
          centerTitle: true,
        ),
        body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                const Text(
                    'What is love?'
                        '-by twice',
                    style: TextStyle(fontSize: 30)
                ),
              ],
            )
        )
    );
  }
}