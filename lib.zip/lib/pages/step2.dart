import 'package:flutter/material.dart';

class step2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('STEP 2'),
          backgroundColor: Colors.red,
          centerTitle: true,
        ),
        body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                const Text(
                    'What is love?'
                        '-by twice',
                    style: TextStyle(fontSize: 30)
                ),
              ],
            )
        )
    );
  }
}