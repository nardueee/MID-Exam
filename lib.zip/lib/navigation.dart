import 'package:flutter/material.dart';
import 'pages/step1.dart';
import 'pages/step3.dart';
import 'pages/step2.dart';
class MainNavigationPage extends StatefulWidget {

  @override
  _MainNavigationPageState createState() => _MainNavigationPageState();
}

class _MainNavigationPageState extends State {
  int _selectedIndex = 0;
  PageController _pageController = PageController(initialPage: 0);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        controller: _pageController,
        children: [
          step1(),
          step2(),
          step3(),
        ],
        onPageChanged: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }


  @override
  void dispose() {
    _pageController.dispose();
      super.dispose();
  }
}