import 'package:flutter/material.dart';
import 'pages/step1.dart'; // Uncommented
import 'pages/step2.dart'; // Uncommented
import 'pages/step3.dart'; // Uncommented
import 'package:carousel_slider/carousel_slider.dart';

void main() {
  runApp(MyApp());
}

final List<Map<String, String>> imgList = [
  {
    'url': 'assets/3.jpg',
    'description': 'STEP 1',
  },
  {
    'url': 'assets/4.jpg',
    'description': 'STEP 2',
  },
  {
    'url': 'assets/5.jpg',
    'description': 'STEP 3',
  },
];

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: const Color(0xFFFFE5B4),
        appBar: AppBar(
          title: Text(
            '',
            style: TextStyle(
              fontSize: 28,
              color: Colors.red,
            ),
          ),
          leading: Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                decoration: const BoxDecoration(
                  color: Colors.black,
                ),
                child: Image.asset(
                  'assets/1.png',
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTracer) => Text(
                    'missing logo',
                    style: TextStyle(
                      color: Colors.red,
                      fontSize: 24,
                    ),
                  ),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.directions),
                title: const Text('STEP 1'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const Step1()),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.directions),
                title: const Text('STEP 2'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const Step2()),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.directions),
                title: const Text('STEP 3'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const Step3()),
                  );
                },
              )
            ],
          ),
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16.5, 16.5, 16.5, 8.10),
              child: Text(
                'Steps on how to cook Buldak noodles🍜',
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20.0),
              child: CarouselSlider(
                options: CarouselOptions(
                  height: 300.0,
                  autoPlay: true,
                  enlargeCenterPage: true,
                ),
                items: imgList.map((item) {
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 5.0),
                    child: Column(
                      children: [
                        Expanded(
                          child: Image.asset( // Changed to Image.asset
                            item['url']!,
                            fit: BoxFit.cover,
                            width: double.infinity,
                            errorBuilder: (context, error, stackTracer) => Icon(Icons.error),
                          ),
                        ),
                        Container(
                          color: Colors.red.withOpacity(0.9),
                          padding: const EdgeInsets.all(8.0),
                          margin: const EdgeInsets.only(top: 8.0),
                          child: Text(
                            item['description']!,
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                            ),
                            textAlign: TextAlign.center,
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                          ),
                        )
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 35.0),
              child: Center(
                child: Image.asset( // Changed to Image.asset
                  'assets/2.jpg',
                  width: 400,
                  height: 300,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Step1 extends StatelessWidget {
  const Step1({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('STEP 1'),
        backgroundColor: Colors.red,
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('What is love?' '-by twice', style: TextStyle(fontSize: 30)),
          ],
        ),
      ),
    );
  }
}

class Step2 extends StatelessWidget {
  const Step2({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('STEP 2'),
        backgroundColor: Colors.red,
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('What is love?' '-by twice', style: TextStyle(fontSize: 30)),
          ],
        ),
      ),
    );
  }
}

class Step3 extends StatelessWidget {
  const Step3({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('STEP 3'),
        backgroundColor: Colors.red,
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('What is love?' '-by twice', style: TextStyle(fontSize: 30)),
          ],
        ),
      ),
    );
  }
}